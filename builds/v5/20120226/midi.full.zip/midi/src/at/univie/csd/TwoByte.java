/**
 * 
 */
package at.univie.csd;

/**
 * Helper Datatype for MidiCSD
 * @author Martin Dobiasch (java portation), Erich Neuwirth
 *
 */
public class TwoByte
{
	public byte lsb;
	public byte msb;
}
